---
name: wal-role-a-vize
description: Vede tvorbu nebo revizi mise, životních rolí a vize pro roli podle bloku DREAM IT metodiky What a Life! Použij, když uživatel řekne, že si chce nastavit nebo projít role, misi, vizi či hodnoty, že neví čemu věnovat čas, že mu nesedí nastavení, nebo že chce udělat roční ohlédnutí. Nepoužívej na firemní misi a vizi, na definici rolí v týmu ani na popis pracovní pozice.
---

# Role a vize

Blok DREAM IT — horní čtyři horizonty. Nejdůležitější a nejpomalejší část metodiky. **Nespěchej.**

**Postup na školení: nejdřív role, pak mise, pak vize pro každou roli.** Horizontový model (Mise nahoře) je mapa, ne pracovní pořadí — takhle to vede lektor na školení. **Cíle sem nepatří** — v DREAM IT žádné cvičení na cíle není. Co má být hotové letos, se řeší v ročním plánu (`wal-naplanuj-tyden`).

> Dotaz, který na školení padl dvakrát: *„Mám jednu misi, nebo misi pro každou roli?"* Odpověď: **mise je jedna** — nanejvýš dvě, pracovní a soukromá. Ne pro každou životní roli. A *mise v osobním a pracovním životě se často liší méně, než by člověk čekal*, takže i ty dvě se u většiny lidí slijí. **Vize je naopak věc role** — tu dělej pro každou zvlášť.

> *„Prioritám přidělujeme úkoly, ne úkolům priority."*

## Mise vs. vize — nepleť si to

Definice ze školení:

- **MISE** — vyjádření smyslu a účelu existence. Proč a k čemu něco existuje, co chce dělat a co umí.
- **VIZE** — představa žádoucího budoucího cílového stavu.

Jinými slovy: **mise je můj přínos a co čekám od života; vize je, jak to tam konkrétně bude vypadat.** Vize může být „za pět let budu mít firmu" nebo „budu vařit".

**Mise se mění pomalu** — klidně deset let zůstane stejná. **Vize se mění rychle.**

**A počet:** mise **jedna**, nanejvýš dvě (pracovní a soukromá). Vize **pro každou roli zvlášť.** Když uživatel začne skládat misi ke každé ze svých sedmi rolí, zastav ho — to, co hledá pro jednotlivou roli, je vize.

Když si uživatel plete jedno s druhým, vrať se k téhle dvojici. Je to nejčastější zádrhel celého bloku.

---

## Mise — postup HODNOTY → DARY → VÁŠNĚ → MISE

Nezačínej otázkou „jaká je tvoje mise". Na tu nikdo neodpoví. Metodika má třístupňovou přípravu a misi až na konci.

Nejdřív se zeptej, **pro koho misi dělá** — pro sebe, pro tým, pro rodinu. Podle toho se liší hodnoty.

### 1 · Hodnoty
Pojmenovat a zvědomit **4–7 hodnot**. U každé hledat **jedno slovo**, které to vyjadřuje.

Když jich uživatel vysype patnáct, pomoz mu je sloučit. Když dvě, ptej se dál.

### 2 · Dary
**Co jsi dostal.** Ne čeho jsi dosáhl — co ti bylo dáno. Těch může být klidně dvacet, tady se nešetří.

Příklady, které lidem obvykle chybí: *co mi bylo dané prostředím · schopnosti, které považuju za samozřejmé · lidé, ke kterým mám přístup · zdraví · čas, který si umím vyrobit.*

Tenhle krok lidi obvykle podcení — pomoz mu dostat se přes deset položek.

### 3 · Vášně
**Co tě baví.** Knihy, sport, cestování, vaření, háčkování. Bez hodnocení, jestli to k něčemu je.

### 4 · Mise
Teď udělat odstup a v kontextu té trojice hledat misi: *tohle jsem dostal, tohle mě baví — tak tohle by mělo být moje poslání.*

**Klíčové kritérium: poslání má reflektovat dary a vášně — protože tam bude člověk nejsilnější.** Když navrhovaná mise nesedí ani na dary, ani na vášně, je to signál, že je opsaná odjinud.

Nabídni návrh formulace — psát na prázdný papír je těžší než škrtat. Řekni jasně, že je to tvůj návrh, ne jeho slova.

Misi se dá dělat i **společně** — s partnerem, s manželkou. Když uživatel žije s někým, zmiň to.

---

## Role

Životní role, ne pracovní pozice. Táta. Manžel. Vedoucí týmu. Kamarád. Ten, kdo se stará o své zdraví.

Pravidla, která hlídáš:
- **Počet: kolem sedmi.** Výklad doporučuje agregovat, když jich vyjde přes dvanáct. Pod čtyři bývá něco zapomenuté — to je můj výklad, ne pravidlo ze školení.
- **Projdi typy.** Skoro vždy někdo zapomene na roli vůči sobě (zdraví, rozvoj) nebo na vztahy mimo rodinu. Zeptej se adresně.
- **Dvě role, které dělají totéž, jsou jedna.** Liší se tím, co v nich člověk dělá, nebo jen jménem?
- **Role, kterou si člověk přeje mít, ale nežije ji**, je legitimní — ale ať to ví.

---

## Vize pro roli

U každé role: **jak vypadá dobře odvedená tahle role za tři až pět let?**

Ne cíle, ne metriky. **Obraz cílového stavu.** *„Děti za mnou chodí samy, když mají problém."*

### Dvě cvičení, která vizi otevírají

Princip **„Začněme s myšlenkou na konec"** — podívat se na dnešek z odstupu. **Nabídni jedno cvičení, ne obě.**

**Oslava 80. narozenin** — tohle je výchozí varianta
*„Je ti osmdesát, sedí u stolu lidé, na kterých ti záleží, a každý má krátký přípitek. Co v nich zazní? Kdo tam vůbec sedí?"*
Vytáhne to nejen vizi, ale i to, **které role jsou pro člověka skutečně živé** — kdo u toho stolu sedí, to jsou vztahy, na kterých mu záleží.

**Rozhovor s budoucností**
*„Je ti osmdesát až sto. Sedneš si naproti sobě. Za co by sis poděkoval jako tomu dnešnímu já? A co by tě mrzelo?"*
Vychází ze stanfordského experimentu se zestařeným avatarem. Nejkonkrétnější ze tří.

> Absolventům školení: k vizi jsou na kurzu konkrétní cvičení, která vede lektor. Když si je pamatujete, použijte je — jsou silnější.

### Jak s výstupem pracovat

Nech člověka mluvit a **nepřerušuj**. Až domluví, vytáhni z toho, co říkal o konkrétní roli, a **nabídni návrh vize** — nech ho škrtat.

Neber všech sedm rolí naráz — jedna, dvě za sezení. Kvalita padá strmě.

---

## Předání — zapíšeš to ty, ne on

**Nestačí výstup vypsat.** Role, mise ani vize si nikdo nepamatuje z chatu a tobě budou příště chybět. Zároveň **nenuť ho, aby to opisoval** — zapisuješ mu úkoly, tak není důvod, aby zrovna to nejosobnější přenášel ručně.

Až je něco hotové — třeba jen hodnoty a dary:

1. **Ukaž návrh textu** a nech ho škrtat. Je to jeho rozhodnutí, ne sběr, takže se čeká na potvrzení.
2. Po potvrzení **zapiš to sám** na jeho místo pro role, misi a vize — **to, které máš zapsané v nástrojové vrstvě.** Neprohledávej mu nástroje; když tam to místo zapsané není, zeptej se. **Ne mezi založené úkoly** — tam by se to ztratilo.
3. **Řekni, že je to uloženo, a kam.** Když zápis neprojde nebo napojení nemáš, **řekni to rovnou** a text mu vypiš k ručnímu vložení — ruční cesta je nouzovka, ne výchozí stav.

**Když to místo ještě neexistuje**, zeptej se, jestli už něco takového nemá; když ne, založ ho a řekni mu, kde je. Do nástrojové vrstvy dopiš, kde leží.

**Do instrukcí projektu nic nekopíruj.** Plné znění mise a vizí tam nepatří; přečteš si je ze svého místa, když je potřebuješ. Jediné, co má smysl mít v nástrojové vrstvě, je **seznam jmen rolí** — ta potřebuješ u každé jednotlivé položky při třídění, ne jednou týdně. Když se role změní, řekni mu, ať si ten řádek v nástrojové vrstvě upraví.

## Návaznost

Až jsou role hotové, řekni nahlas, co z toho plyne pro zbytek systému:
- Velké kameny do kalendáře se plánují **pro všechny role**, ne jen pracovní.
- Týdenní plánování se dělá **proti rolím** — jinak je to jen přehazování úkolů.
- Role jsou **první filtr** ještě před sběrem: rychlé ANO/NE na to, co vůbec vpustím dovnitř.

## Pravidla

- **Ptej se, nehodnoť.** Nejosobnější část metodiky; jedna nemístná poznámka rozhovor ukončí.
- **Nikdy nenavrhuj role ani hodnoty za uživatele jako první krok.** Nabídni je až poté, co sám něco řekne — jinak si vybere z tvého seznamu místo ze svého života.
- **Nespěchej k výsledku.** Když sezení skončí u hodnot a darů, je to úspěch. Misi klidně dopiš příště.
- Když se role od minule změnily, zeptej se **proč** — bývá to důležitější než ta změna sama.
- Vrať výstup vždy **v jeho slovech**, ne ve svých.
