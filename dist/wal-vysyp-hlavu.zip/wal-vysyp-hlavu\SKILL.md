---
name: wal-vysyp-hlavu
description: Vedený mind sweep podle metodiky What a Life! — postupné vyprázdnění hlavy po šesti oblastech pomocí spouštěcích otázek. Použij, když uživatel řekne, že má plnou hlavu, že mu něco uniká, že se mu honí myšlenky, nemůže spát kvůli nedořešeným věcem, nebo si výslovně řekne o mind sweep či vysypání hlavy. Nepoužívej na běžný brainstorming nápadů ani na plánování projektu.
---

# Vysyp hlavu

Vedeš uživatele vyprázdněním hlavy. Cílem je dostat ven **úplně všechno**, co mu leží v hlavě — velké i směšně malé. Metodika tomu říká *debordelizace hlavy*.

## Železné pravidlo

**Netřídíš, nehodnotíš, neradíš, nenavrhuješ řešení.** Jen sbíráš.

Jakmile začneš rozhodovat, uživatel si přestane vzpomínat. Třídění přijde až potom, samostatným krokem.

## Postup

Ptej se **po jedné oblasti**. Vždy jen jedna, pak počkej na odpověď. Nikdy nevysyp všech šest oblastí najednou.

U každé oblasti dej **3–5 konkrétních spouštěcích otázek**, ne jednu obecnou. Obecná otázka („co tě čeká v práci?") vytáhne tři věci; konkrétní otázky vytáhnou patnáct.

Když uživatel odpoví krátce nebo obecně, **zeptej se ještě jednou jinak**. Teprve pak jdi dál. Typicky: *„Ještě něco, co se ti vrací, i když bys to radši neřešil?"*

## Oblasti v tomto pořadí

1. **Práce** — rozdělané věci · sliby, které jsi dal · na co čekáš od druhých · co ti leží ve schránce · co se má stát do měsíce
2. **Domácnost a peníze** — opravy · nákupy · platby a smlouvy · papírování · věci, co se rozbily
3. **Zdraví a energie** — odkládané kontroly · pohyb · spánek · co ti dlouhodobě nedělá dobře
4. **Vztahy** — komu jsi něco slíbil · komu ses dlouho neozval · narozeniny a výročí · co s kým potřebuješ probrat
5. **Rozvoj** — co se chceš naučit · co máš rozečtené · co odkládáš roky
6. **Nedořešené a nepříjemné** — čemu se vyhýbáš · co tě budí ve tři ráno · co bys nejradši nevěděl

## Konec

Až projdete všech šest, teprve pak vrať **kompletní seznam všeho**, co uživatel řekl — jako prostý seznam, bez třídění, bez kategorií, bez komentáře. Zachovej jeho slova, nepřeformulovávej.

Pak řekni jednu větu: že tohle je surový materiál a že další krok je roztřídit ho do sedmi destinací. Nabídni to, ale nedělej to sám, dokud nepotvrdí.

## Než začneš

Když uživatel ještě nemá **role a misi**, zmiň to **jednou větou** a nabídni, jestli nechce začít jimi — role jsou první filtr, podle kterého se pak třídí. Pak se ale zeptej, co chce, a **respektuj odpověď**. Vysypání hlavy funguje i bez rolí; jen si poznamenej, že se k tomu seznamu vrátíte, až role budou.

## Škálování

Když má uživatel málo času, nabídni **mini verzi**: jen oblasti 1, 4 a 6, po dvou otázkách. Lepší patnáct minut než nic.
